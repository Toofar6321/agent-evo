#!/bin/bash
# ═══════════════════════════════════════════
# The Agency — Install Script for Claude Code
# Usage: ./scripts/install-claude-code.sh
# ═══════════════════════════════════════════

set -e

AGENTS_DIR="$HOME/.claude/agents"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo ""
echo "╔══════════════════════════════════════╗"
echo "║     THE AGENCY — Claude Code Setup   ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Create Claude Code agents directory if it doesn't exist
mkdir -p "$AGENTS_DIR"

# Track counts
installed=0
skipped=0

# Find and install all .md agent files
while IFS= read -r -d '' agent_file; do
  division=$(basename "$(dirname "$agent_file")")
  agent_name=$(basename "$agent_file" .md)
  dest="$AGENTS_DIR/${division}-${agent_name}.md"

  if [ -f "$dest" ]; then
    echo "  ↷ SKIP    $division/$agent_name.md (already installed)"
    ((skipped++))
  else
    cp "$agent_file" "$dest"
    echo "  ✓ INSTALL $division/$agent_name.md"
    ((installed++))
  fi
done < <(find "$SOURCE_DIR" -path "$SOURCE_DIR/scripts" -prune -o \
  -name "*.md" ! -name "README.md" -print0)

echo ""
echo "────────────────────────────────────────"
echo "  Installed: $installed agents"
echo "  Skipped:   $skipped (already present)"
echo "  Location:  $AGENTS_DIR"
echo "────────────────────────────────────────"
echo ""
echo "  Activate in Claude Code:"
echo "  > 'Activate PIXEL and help me build a React nav'"
echo "  > 'Activate FORGE and design a REST API for offers'"
echo "  > 'Activate CLOSE and help me handle a price objection'"
echo ""
